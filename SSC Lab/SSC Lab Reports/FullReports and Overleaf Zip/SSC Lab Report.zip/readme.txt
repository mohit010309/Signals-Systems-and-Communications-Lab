main.tex is the main file to compile. 
Include the content of each experiment in separate chapters. 